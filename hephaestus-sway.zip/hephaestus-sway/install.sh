#!/bin/bash
# =============================================================================
# Hephaestus (Pi 5) — Stack B Bootstrap
# Debian + Sway + Oxocarbon
# Run as your normal user (not root). sudo will be called where needed.
# =============================================================================

set -e

echo "============================================================"
echo " Hephaestus Stack B — Install Script"
echo "============================================================"

# --- System update -----------------------------------------------------------
sudo apt update && sudo apt upgrade -y

# --- Core Sway stack ---------------------------------------------------------
sudo apt install -y \
    sway \
    swaylock \
    swayidle \
    swaybg \
    waybar \
    wofi \
    mako-notifier \
    grimshot \
    kitty \
    foot \
    xdg-user-dirs \
    xdg-utils \
    xwayland

# --- Fonts -------------------------------------------------------------------
sudo apt install -y fonts-firacode

# Note: FiraCode Nerd Font (patched) may need manual install from nerdfonts.com
# Download FiraCode Nerd Font, extract to ~/.local/share/fonts/, run: fc-cache -fv

# --- Audio -------------------------------------------------------------------
sudo apt install -y \
    pipewire \
    pipewire-pulse \
    wireplumber \
    pavucontrol \
    playerctl

# --- Network -----------------------------------------------------------------
sudo apt install -y \
    network-manager \
    nm-tray

# --- CLI tools ---------------------------------------------------------------
sudo apt install -y \
    zsh \
    git \
    curl \
    wget \
    htop \
    btop \
    fzf \
    ripgrep \
    fd-find \
    bat \
    eza \
    yazi \
    tmux \
    unzip

# --- Embedded / workshop tools -----------------------------------------------
sudo apt install -y \
    python3 \
    python3-pip \
    python3-venv \
    platformio \
    screen \
    minicom \
    picocom

# Add user to dialout for serial access
sudo usermod -aG dialout "$USER"

# --- Browser -----------------------------------------------------------------
sudo apt install -y firefox-esr

# --- Tailscale ---------------------------------------------------------------
curl -fsSL https://tailscale.com/install.sh | sh

# --- Deploy configs ----------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p ~/.config/sway
mkdir -p ~/.config/waybar
mkdir -p ~/.config/wofi
mkdir -p ~/.config/kitty
mkdir -p ~/.config/mako

cp "$SCRIPT_DIR/sway/config"           ~/.config/sway/config
cp "$SCRIPT_DIR/waybar/config.jsonc"   ~/.config/waybar/config.jsonc
cp "$SCRIPT_DIR/waybar/style.css"      ~/.config/waybar/style.css
cp "$SCRIPT_DIR/wofi/config"           ~/.config/wofi/config
cp "$SCRIPT_DIR/wofi/style.css"        ~/.config/wofi/style.css
cp "$SCRIPT_DIR/kitty/kitty.conf"      ~/.config/kitty/kitty.conf

echo "============================================================"
echo " Done! A few manual steps remain:"
echo ""
echo " 1. Log out and start Sway:"
echo "    From TTY: exec sway"
echo ""
echo " 2. Check your monitor output name:"
echo "    swaymsg -t get_outputs"
echo "    Then uncomment + edit the output line in ~/.config/sway/config"
echo ""
echo " 3. Install FiraCode Nerd Font if the apt version looks wrong:"
echo "    Download from nerdfonts.com, extract to ~/.local/share/fonts/"
echo "    Run: fc-cache -fv"
echo ""
echo " 4. Enable Tailscale:"
echo "    sudo tailscale up"
echo ""
echo " 5. Add user to dialout took effect — log out and back in"
echo "    or reboot before flashing anything."
echo "============================================================"
